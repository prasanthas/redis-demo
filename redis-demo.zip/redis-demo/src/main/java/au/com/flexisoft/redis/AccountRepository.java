package au.com.flexisoft.redis;

//public class AccountRepository implements CrudRepository<Account> {
public class AccountRepository {
}
