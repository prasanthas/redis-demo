package au.com.flexisoft.redis;

import org.springframework.boot.SpringApplication;

//@SpringBootApplication
public class RedisSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedisSpringBootApplication.class,args);
    }
}
